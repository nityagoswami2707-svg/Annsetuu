import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';

import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ImpactReceipt from './components/ImpactReceipt';
import ToastContainer from './components/ToastContainer';
import MobileBottomNav from './components/MobileBottomNav';
import PwaInstallBanner from './components/PwaInstallBanner';
import ProtectedRoute from './components/ProtectedRoute';

import Home from './pages/Home';
import AdminDashboard from './pages/AdminDashboard';
import DonorDashboard from './pages/DonorDashboard';
import NgoDashboard from './pages/NgoDashboard';
import TrackingDashboard from './pages/TrackingDashboard';
import DeliveryDashboard from './pages/DeliveryDashboard';
import ImpactPage from './pages/ImpactPage';
import AuthPage from './pages/AuthPage';
import AccessDenied from './pages/AccessDenied';
import CertificatesDashboard from './pages/CertificatesDashboard';
import CertificateVerifyPage from './pages/CertificateVerifyPage';
import UserProfilePage from './pages/UserProfilePage';
import UserProfileBox from './components/UserProfileBox';

// Professional 1.5s Site Startup Loading Overlay
function SiteStartupLoader() {
  const [loading, setLoading] = useState(() => {
    return !sessionStorage.getItem('annsetu_loaded_splash');
  });

  useEffect(() => {
    if (loading) {
      sessionStorage.setItem('annsetu_loaded_splash', 'true');
      const timer = setTimeout(() => setLoading(false), 1400);
      return () => clearTimeout(timer);
    }
  }, [loading]);

  if (!loading) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-[#064e3b] text-white flex flex-col items-center justify-center p-4 animate-out fade-out duration-500">
      <div className="space-y-4 text-center animate-pulse">
        <div className="relative bg-white rounded-3xl p-3 shadow-2xl inline-block border-2 border-amber-400">
          <img src="/annsetu_logo.png" alt="AnnSetu" className="h-16 w-auto object-contain" />
        </div>
        <h1 className="text-3xl font-black font-outfit tracking-tight">
          Ann<span className="text-orange-400">setu</span>
        </h1>
        <p className="text-xs font-bold text-emerald-200 uppercase tracking-widest">
          Connecting surplus with smiles...
        </p>

        <div className="flex items-center justify-center space-x-2 pt-2 text-amber-400">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-orange-400 animate-ping delay-100"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping delay-200"></span>
        </div>
      </div>
    </div>
  );
}

// Component to guarantee homepage appears first every time someone opens the website
function AlwaysOpenHomepageOnVisit() {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const visited = sessionStorage.getItem('annsetu_visited_session');
    if (!visited) {
      sessionStorage.setItem('annsetu_visited_session', 'true');
      if (location.pathname !== '/') {
        navigate('/', { replace: true });
      }
    }
  }, [navigate, location]);

  return null;
}

// Component to handle offline network status gracefully on mobile
function OfflineNetworkBanner() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isOffline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[110] bg-orange-600 text-white text-xs font-bold px-4 py-2 text-center shadow-lg flex items-center justify-center space-x-2 animate-in slide-in-from-top">
      <span>⚠️ Connection problem. You are offline. Some live AnnSetu features require internet.</span>
      <button onClick={() => window.location.reload()} className="underline font-black bg-black/20 px-2 py-0.5 rounded cursor-pointer">Retry</button>
    </div>
  );
}

// Component to render dashboard with Profile side drawer for /profile route
function ProfilePageRoute() {
  const { currentUser } = useApp();
  const navigate = useNavigate();

  if (!currentUser) return <Navigate to="/auth/donor" replace />;

  const userDashboard = currentUser.role === 'admin' ? '/admin' : currentUser.role === 'ngo' ? '/ngo' : currentUser.role === 'volunteer' ? '/delivery' : '/donor';

  const handleClose = () => {
    navigate(userDashboard, { replace: true });
  };

  return (
    <>
      {currentUser.role === 'donor' && <DonorDashboard />}
      {currentUser.role === 'ngo' && <NgoDashboard />}
      {currentUser.role === 'volunteer' && <DeliveryDashboard />}
      {currentUser.role === 'admin' && <AdminDashboard />}
      <UserProfileBox onClose={handleClose} />
    </>
  );
}

function AppContent() {
  const { selectedReceiptDonation, setSelectedReceiptDonation } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#064e3b] text-white font-sans antialiased selection:bg-amber-400 selection:text-gray-950 overflow-x-hidden">
      <SiteStartupLoader />
      <AlwaysOpenHomepageOnVisit />
      <OfflineNetworkBanner />
      <Navbar />
      <ToastContainer />
      <PwaInstallBanner />

      <main className="flex-1 pb-20 lg:pb-0">
        <Routes>
          {/* Public Homepage always opens first */}
          <Route path="/" element={<Home />} />
          
          {/* Authentication Routes */}
          <Route path="/auth/:roleParam" element={<AuthPage />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="/access-denied" element={<AccessDenied />} />

          {/* Role-Based Protected Routes */}
          <Route 
            path="/donor" 
            element={
              <ProtectedRoute allowedRoles={['donor']}>
                <DonorDashboard />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/ngo" 
            element={
              <ProtectedRoute allowedRoles={['ngo']}>
                <NgoDashboard />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/delivery" 
            element={
              <ProtectedRoute allowedRoles={['volunteer']}>
                <DeliveryDashboard />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/admin" 
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/certificates" 
            element={
              <ProtectedRoute allowedRoles={['donor', 'ngo', 'volunteer', 'admin']}>
                <CertificatesDashboard />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/profile" 
            element={
              <ProtectedRoute allowedRoles={['donor', 'ngo', 'volunteer', 'admin']}>
                <ProfilePageRoute />
              </ProtectedRoute>
            } 
          />

          <Route 
            path="/my-profile" 
            element={
              <ProtectedRoute allowedRoles={['donor', 'ngo', 'volunteer', 'admin']}>
                <ProfilePageRoute />
              </ProtectedRoute>
            } 
          />

          {/* Public Impact Page & Verification */}
          <Route path="/impact" element={<ImpactPage />} />
          <Route path="/my-impact" element={<Navigate to="/impact" replace />} />
          <Route 
            path="/track" 
            element={
              <ProtectedRoute allowedRoles={['donor', 'ngo', 'volunteer', 'admin']}>
                <TrackingDashboard />
              </ProtectedRoute>
            } 
          />
          <Route path="/certificate/verify/:code" element={<CertificateVerifyPage />} />

          {/* Fallback to Homepage */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <Footer />
      <MobileBottomNav />

      {/* Global Impact Receipt Modal */}
      {selectedReceiptDonation && (
        <ImpactReceipt
          donation={selectedReceiptDonation}
          onClose={() => setSelectedReceiptDonation(null)}
        />
      )}
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <Router>
        <AppContent />
      </Router>
    </AppProvider>
  );
}

export default App;
